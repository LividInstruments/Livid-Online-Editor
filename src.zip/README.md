# Livid-Online-Editor
HTML, JS, and media for the Livid Online MIDI Editor

You can run the Livid editor locally to modify your Livid Controller by downloading this repo (look for the green button!) and opening "index.html" in Google Chrome browser.
