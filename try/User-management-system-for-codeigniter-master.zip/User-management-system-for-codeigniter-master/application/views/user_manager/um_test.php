<a href="register">register</a><br/>
<a href="login">login</a><br/>
<a href="reset">reset</a><br/>
<a href="resetpass">resetpass</a><br/>
<a href="profile">profile</a><br/>
<a href="editprofile">editprofile</a><br/>
<a href="logout">logout</a><br/>
<a href="activate">activate</a>
