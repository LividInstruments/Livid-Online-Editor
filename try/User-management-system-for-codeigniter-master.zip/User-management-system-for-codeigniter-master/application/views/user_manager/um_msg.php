<?php
echo $msg;

?>
